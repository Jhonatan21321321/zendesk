(function () {
    'use strict';

    const THRESHOLD_YELLOW_MS    = 120000;
    const THRESHOLD_RED_MS       = 240000;
    const INIT_DELAY_MS          = 3000;
    const NAV_RESCAN_DELAY_MS    = 1200;
    const NOTIF_BTN_CACHE_TTL_MS = 8000;
    const SEL_MSG_ROOT           = '.iACaSM';
    const SEL_TIME               = '.iACaSM time';
    const SEL_SPAN               = '.iACaSM span.kawtYt';
    const CSS_WHITE              = 'znk-pulse-white';
    const CSS_YELLOW             = 'znk-pulse-yellow';
    const CSS_RED                = 'znk-pulse-red';
    const ALL_CSS                = [CSS_WHITE, CSS_YELLOW, CSS_RED];

    const state = {
        lastMessageAt:     null,
        cycleStartedAt:    null,
        hasUnread:         false,
        viewedWhileUnread: false,
        unreadCount:       0,
        knownTimestamps:   new Set(),
        lastKnownSender:   null,
        initialized:       false,
        originalTitle:     document.title,
        lastUrl:           location.href,
    };

    // ─── Substituição do GM_addStyle por injeção nativa ───────────────────────
    function injectStyles(css) {
        const style = document.createElement('style');
        style.textContent = css;
        (document.head || document.documentElement).appendChild(style);
    }

    injectStyles(`
        .${CSS_WHITE}  { background-color: #fff    !important; animation: znk-white  1.5s infinite; box-shadow: 0 0 6px rgba(0,0,0,.25); }
        .${CSS_YELLOW} { background-color: #ffeb3b !important; animation: znk-yellow 1.5s infinite; }
        .${CSS_RED}    { background-color: #f44336 !important; animation: znk-red    1.5s infinite; }
        @keyframes znk-white  { 0%,100%{background-color:#fff}    50%{background-color:#f0f0f0} }
        @keyframes znk-yellow { 0%,100%{background-color:#ffeb3b} 50%{background-color:#ffc107} }
        @keyframes znk-red    { 0%,100%{background-color:#f44336} 50%{background-color:#c62828} }

        #znk-hud {
            position: fixed; top: 8px; left: 50%; transform: translateX(-50%); z-index: 99999;
            display: flex; align-items: center; gap: 8px;
            background: rgba(30,30,30,0.92); color: #fff;
            font: 12px/1 monospace; padding: 5px 10px;
            border-radius: 20px; box-shadow: 0 2px 12px rgba(0,0,0,0.4);
            user-select: none; opacity: 0.55; transition: opacity 0.2s;
            pointer-events: none;
        }
        #znk-hud:hover { opacity: 1; pointer-events: auto; }
        #znk-dot {
            width: 8px; height: 8px; border-radius: 50%;
            background: #4caf50; flex-shrink: 0; transition: background 0.4s;
        }
        #znk-dot.yellow { background: #ffeb3b; }
        #znk-dot.red    { background: #f44336; animation: znk-blink 0.8s infinite; }
        #znk-dot.frozen { background: #888;    animation: znk-blink 1.2s infinite; }
        @keyframes znk-blink { 0%,100%{opacity:1} 50%{opacity:0.2} }
    `);

    // ─── Worker ───────────────────────────────────────────────────────────────
    let worker = null;

    function createWorker() {
        const code = `
            let interval = null;
            self.onmessage = function(e) {
                if (e.data === 'start' && !interval) interval = setInterval(() => self.postMessage('tick'), 1000);
                if (e.data === 'stop') { clearInterval(interval); interval = null; }
            };
        `;
        return new Worker(URL.createObjectURL(new Blob([code], { type: 'application/javascript' })));
    }

    function startWorker() {
        if (worker) worker.terminate();
        worker = createWorker();
        worker.onmessage = (e) => { if (e.data === 'tick') tick(); };
        worker.onerror   = () => { worker = null; setInterval(tick, 1000); };
        worker.postMessage('start');
    }

    function fallbackTimer() { setInterval(tick, 1000); }

    // ─── HUD ──────────────────────────────────────────────────────────────────
    let hudDot, hudTime;

    function buildHud() {
        const hud = document.createElement('div');
        hud.id    = 'znk-hud';
        hudDot    = document.createElement('span'); hudDot.id = 'znk-dot'; hudDot.className = '';
        hudTime   = document.createElement('span'); hudTime.textContent = '0m 00s';
        hud.append(hudDot, hudTime);
        document.body.appendChild(hud);
        setHudStatus('green');
    }

    function setHudStatus(status) {
        if (!hudDot) return;
        hudDot.className = status === 'yellow' ? 'yellow'
                         : status === 'red'    ? 'red'
                         : status === 'frozen' ? 'frozen' : '';
    }

    // ─── Notification button (cache) ─────────────────────────────────────────
    let _cachedBtn = null, _cachedBtnAt = 0;

    function getNotificationButton() {
        const now = Date.now();
        if (_cachedBtn && document.contains(_cachedBtn) && (now - _cachedBtnAt) < NOTIF_BTN_CACHE_TTL_MS) return _cachedBtn;
        const cache = b => { _cachedBtn = b; _cachedBtnAt = Date.now(); return b; };
        for (const b of document.querySelectorAll('nav button, nav [role="button"]')) {
            if (b.offsetWidth > 0 && b.querySelector('svg')) return cache(b);
        }
        return null;
    }

    // ─── Status ──────────────────────────────────────────────────────────────
    function deriveStatus() {
        if (!state.hasUnread || state.viewedWhileUnread) return 'green';
        const e = state.cycleStartedAt ? Date.now() - state.cycleStartedAt : 0;
        if (e > THRESHOLD_RED_MS)    return 'red';
        if (e > THRESHOLD_YELLOW_MS) return 'yellow';
        return 'white';
    }

    function formatElapsed(ms) {
        const s = Math.max(0, Math.floor(ms / 1000));
        return `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, '0')}s`;
    }

    // ─── Tick ─────────────────────────────────────────────────────────────────
    function tick() {
        const times   = document.querySelectorAll(SEL_TIME);
        const spans   = document.querySelectorAll(SEL_SPAN);
        const btn     = getNotificationButton();
        const status  = deriveStatus();
        const elapsed = state.cycleStartedAt ? Date.now() - state.cycleStartedAt : 0;

        if (!document.hidden && state.hasUnread && !state.viewedWhileUnread) {
            state.viewedWhileUnread = true;
        }

        if (!times.length) {
            document.title = state.originalTitle;
        } else {
            const timeStr  = `[${formatElapsed(elapsed)}]`;
            const lastName = spans.length ? spans[spans.length - 1].textContent.trim() : '';
            const icons    = { red: '🔴', yellow: '🟡', white: '⚪', green: '🟢' };
            const tag    = state.hasUnread && !state.viewedWhileUnread && state.unreadCount > 0 ? `M${state.unreadCount} ` : '';
            const prefix = `${icons[status]} ${tag}`;
            document.title = lastName
                ? `${prefix}${timeStr} ${lastName} - ${state.originalTitle}`
                : `${prefix}${timeStr} ${state.originalTitle}`;
        }

        if (btn) {
            btn.classList.remove(...ALL_CSS);
            if (times.length) {
                if (status === 'white')  btn.classList.add(CSS_WHITE);
                if (status === 'yellow') btn.classList.add(CSS_YELLOW);
                if (status === 'red')    btn.classList.add(CSS_RED);
            }
        }

        if (hudTime) hudTime.textContent = formatElapsed(elapsed);
        setHudStatus(status);
    }

    // ─── getCurrentSender ────────────────────────────────────────────────────
    function getCurrentSender() {
        const items = document.querySelectorAll(SEL_MSG_ROOT);
        for (let i = items.length - 1; i >= 0; i--) {
            const s = items[i].querySelector('span.kawtYt');
            if (s && s.textContent.trim()) return s.textContent.trim();
        }
        return null;
    }

    // ─── scanForNewMessages ───────────────────────────────────────────────────
    function scanForNewMessages() {
        const times = document.querySelectorAll(SEL_TIME);
        if (!times.length) return;

        if (!state.initialized) {
            state.initialized     = true;
            state.lastKnownSender = getCurrentSender();
            state.lastMessageAt   = new Date(times[times.length - 1].dateTime);
            state.cycleStartedAt  = null;
            times.forEach(t => state.knownTimestamps.add(t.dateTime));
            return;
        }

        let newCount = 0;
        times.forEach(t => {
            if (!state.knownTimestamps.has(t.dateTime)) {
                state.knownTimestamps.add(t.dateTime);
                newCount++;
            }
        });

        if (newCount === 0) return;

        const messageTime   = new Date(times[times.length - 1].dateTime);
        const currentSender = getCurrentSender();
        const samePerson    = state.lastKnownSender && currentSender && currentSender === state.lastKnownSender;

        if (samePerson) {
            state.unreadCount  += newCount;
        } else {
            state.cycleStartedAt    = Date.now();
            state.lastMessageAt     = messageTime;
            state.unreadCount       = newCount;
            state.lastKnownSender   = currentSender;
            state.viewedWhileUnread = false;
        }

        if (!state.cycleStartedAt) {
            state.cycleStartedAt = Date.now();
        }

        state.hasUnread         = true;
        state.viewedWhileUnread = false;
        state.lastKnownSender   = currentSender;
    }

    // ─── Observers ───────────────────────────────────────────────────────────
    let msgObserver = null, bodyObsStarted = false;

    function attachMsgObserver() {
        if (msgObserver) { msgObserver.disconnect(); msgObserver = null; }
        const root = document.querySelector(SEL_MSG_ROOT);
        if (!root) return;
        const container = root.parentElement;
        if (!container) return;
        msgObserver = new MutationObserver(scanForNewMessages);
        msgObserver.observe(container, { childList: true, subtree: false });
        scanForNewMessages();
    }

    function detachMsgObserver() {
        if (msgObserver) { msgObserver.disconnect(); msgObserver = null; }
    }

    function startBodyObserver() {
        if (bodyObsStarted) return;
        bodyObsStarted = true;
        new MutationObserver(() => {
            if (location.href !== state.lastUrl) {
                state.lastUrl = location.href;
                Object.assign(state, {
                    lastMessageAt: null, cycleStartedAt: null, hasUnread: false,
                    viewedWhileUnread: false, unreadCount: 0,
                    knownTimestamps: new Set(), lastKnownSender: null,
                    initialized: false,
                });
                _cachedBtn     = null;
                document.title = state.originalTitle;
                detachMsgObserver();
                setTimeout(attachMsgObserver, NAV_RESCAN_DELAY_MS);
                return;
            }
            const root = document.querySelector(SEL_MSG_ROOT);
            if (root && !msgObserver)      attachMsgObserver();
            else if (!root && msgObserver) detachMsgObserver();
        }).observe(document.body, { childList: true });
    }

    // ─── Visibility change ────────────────────────────────────────────────────
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            scanForNewMessages();
            tick();
            if (state.hasUnread) {
                state.viewedWhileUnread = true;
                state.unreadCount       = 0;
                state.cycleStartedAt    = null;
                const btn = getNotificationButton();
                if (btn) btn.classList.remove(...ALL_CSS);
            }
        }
    });

    // ─── Boot ─────────────────────────────────────────────────────────────────
    window.addEventListener('load', () => {
        setTimeout(() => {
            buildHud();
            startBodyObserver();
            attachMsgObserver();
            typeof Worker !== 'undefined' ? startWorker() : fallbackTimer();
        }, INIT_DELAY_MS);
    });

})();